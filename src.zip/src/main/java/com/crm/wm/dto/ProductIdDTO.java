package com.crm.wm.dto;

public class ProductIdDTO {
    private Long productId;

    // Getters and setters

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }
}

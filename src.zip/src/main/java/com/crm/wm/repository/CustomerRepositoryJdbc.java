package com.crm.wm.repository;

import org.springframework.stereotype.Repository;

@Repository
public class CustomerRepositoryJdbc {


    // Add JDBC queries if needed
}

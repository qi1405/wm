package com.crm.wm.repository;

import com.crm.wm.dto.MunicipalityDTO;
import com.crm.wm.dto.ProductDTO;
import com.crm.wm.entities.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class ProductRepositoryJdbc {
}

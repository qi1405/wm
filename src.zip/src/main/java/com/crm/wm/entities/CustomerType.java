package com.crm.wm.entities;

public enum CustomerType {
    COMPANY,
    INDIVIDUAL
}
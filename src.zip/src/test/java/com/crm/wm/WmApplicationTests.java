package com.crm.wm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WmApplicationTests {

	@Test
	void contextLoads() {
	}

}
